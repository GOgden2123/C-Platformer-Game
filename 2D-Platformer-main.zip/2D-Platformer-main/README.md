# 2D-Platformer

--------------------------------------------------------------------------------
Project Motivation
--------------------------------------------------------------------------------

WHAT are we making?
  • A 2D Platformer

WHY are we making it?
  • To learn core concepts in professional programming
  • To create a project to add to a portfolio
  • Games are fun to play and share with others

WHO are we making it for?
  • A small group of friends and family
  • PC users (Windows and Linux)

HOW are we making it?
  • It will be programmed in C/C++ utilizing the SDL library

WHEN are we making it?
  • There will be no foreseeable deadline
  • Project will be implemented in milestones with reasonable deadlines
