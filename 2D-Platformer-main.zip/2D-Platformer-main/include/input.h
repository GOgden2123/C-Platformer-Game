#ifndef INPUT_H
#define INPUT_H

//SDL library
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

//input objects (keyboard and mouse state etc.)
static SDL_Event event;
static const unsigned char* keysPressed;
static SDL_Point mousePos = {0,0};
static unsigned int mouseButtons;

static unsigned long lastTick, currentTick;
static double FPS;
static double FPS_delay;

void setFPS(double dFPS){
    FPS = dFPS;
    FPS_delay = 1000.0 / FPS;

    return;
}

int syncFPS(){
    //sync the game to a prescribed frame rate
    while(currentTick - lastTick < FPS_delay){
        currentTick = SDL_GetTicks64();
    }

    lastTick = currentTick;

    return 0;
}

#endif

