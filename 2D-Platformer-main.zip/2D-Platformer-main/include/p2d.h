#ifndef P2D_H
#define P2D_H

//standard C library
#include <stdio.h>

//SDL library
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

//2D Platformer libraries
#include "rendering.h"
#include "input.h"

static bool gameRunning = false;
SDL_Texture* bg;

#endif


