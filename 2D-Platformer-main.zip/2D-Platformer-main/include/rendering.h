#ifndef RENDERING_H
#define RENDERING_H

//SDL library
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

//window and rendering context objects
static SDL_Window* window = NULL;
static int window_w = 800;
static int window_h = 600;
static SDL_Renderer * renderer = NULL;
static SDL_Rect display = {0,0,window_w,window_h};

#endif

