#include "p2d.h"

int init(){
    //initialize SDL and game objects

    //initialize SDL
    if(SDL_Init(SDL_INIT_EVERYTHING)<0){
        printf("Error initializing SDL: %s\n", SDL_GetError());

        return -1;
    }

    //create game window
    window = SDL_CreateWindow(
        "2D Platformer" //Title of game window
        ,SDL_WINDOWPOS_CENTERED //x position of window on screen
        ,SDL_WINDOWPOS_CENTERED //y position of window on screen
        ,window_w, window_h //size of window
        ,SDL_WINDOW_SHOWN //SDL window flags
    );

    if(window == NULL){
        printf("Error creating Window: %s\n", SDL_GetError());

        return -1;
    }

    //create rendering context
    renderer = SDL_CreateRenderer(
        window //the window to which the renderer belongs
        ,-1 //flag to use the first suitable graphics driver
        ,0 //SDL rendering flags
    );

    if(renderer == NULL){
        printf("Error creating Rendering Context: %s\n", SDL_GetError());

        return -1;
    }

    //get keyboard state
    keysPressed = SDL_GetKeyboardState(NULL);

    //get mouse state
    mouseButtons = SDL_GetMouseState(&mousePos.x, &mousePos.y);

    SDL_Surface* temp = SDL_CreateRGBSurfaceWithFormat(0,window_w,window_h,32,SDL_PIXELFORMAT_ARGB8888);
    SDL_FillRect(temp,NULL,SDL_MapRGBA(temp->format,255,0,0,255));
    bg = SDL_CreateTextureFromSurface(renderer,temp);
    SDL_FreeSurface(temp);

    return 0;
}

int handleEvents(){
    //poll events until there are none left in the queue
    while(SDL_PollEvent(&event)>0){
        if(event.type == SDL_QUIT){
            gameRunning = false;
        }
    }

    //update keyboard state
    keysPressed = SDL_GetKeyboardState(NULL);

    //update mouse state
    mouseButtons = SDL_GetMouseState(&mousePos.x, &mousePos.y);

    //set the FPS
    setFPS(40);

    return 0;
}

int update(){

    return 0;
}

int render(){
    //render the screen
    SDL_RenderCopy(renderer,bg,NULL,&display);
    SDL_RenderPresent(renderer);

    return 0;
}

int quit(){
    //clean up
    SDL_DestroyTexture(bg);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    //un-initialize SDL
    SDL_Quit();

    return 0;
}

int main(int argc, char* argv[]){
    //initialize the game and quit on failure
    if(init()<0){
        return -1;
    }
    else{
        gameRunning = true;
    }

    //begin main game loop
    while(gameRunning){
        handleEvents();
        update();
        render();
        syncFPS(); //defined in "input.h"
    }

    //after main loop, quit gracefully
    quit();

    return 0;
}

